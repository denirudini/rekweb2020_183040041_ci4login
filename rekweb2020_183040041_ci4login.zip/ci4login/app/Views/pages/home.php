<?= $this->extend('layout/template') ?>

<?= $this->section('content') ?>
<div class="container mt-4">
  <div class="row">
    <div class="col">
      <h1>Hallo Nama Saya :<u>Deni Rudini</u> NRP : 183040041.</h1>
    </div>
  </div>
</div>
<?= $this->endSection() ?>